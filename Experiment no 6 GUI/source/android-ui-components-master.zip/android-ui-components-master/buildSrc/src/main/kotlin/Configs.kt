object Configs {

    const val compileSdkVersion = 29
    const val minSdkVersion = 21
    const val targetSdkVersion = 29
    const val buildToolsVersion = "29.0.3"

    const val applicationId = "com.trendyol.uicomponents"
    const val group = "com.trendyol.ui-components"
}
