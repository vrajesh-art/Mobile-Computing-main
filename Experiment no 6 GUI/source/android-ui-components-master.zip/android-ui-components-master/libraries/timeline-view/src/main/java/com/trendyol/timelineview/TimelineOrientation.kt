package com.trendyol.timelineview

enum class TimelineOrientation {
    HORIZONTAL,VERTICAL
}