package com.trendyol.cardinputview

data class CardInformation(
    val cardNumber: String = "",
    val cvv: String = "",
    val expiryMonth: String = "",
    val expiryYear: String = ""
)
